from django.contrib import admin
from .models import CustomerModel
# Register your models here.

admin.site.register(CustomerModel)